  

    <section class="section bg-light element-animate w-100" style="overflow: hidden;">

      <div class="clearfix mb-5 pb-5">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12 text-center heading-wrap">
              <h2>Kegiatan terbaru kami</h2>
              <span class="back-text-dark">DOKUMENTASI</span>
            </div>
          </div>
        </div>
      </div>

      <div class="container">
        
        <div class="row no-gutters">
          <?= $documentation ?>
        </div>
      </div>
    </section> <!-- .section -->

   