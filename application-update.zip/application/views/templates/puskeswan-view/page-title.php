

<div class="logo float-left">
<img class="mb-2" src="<?= base_url('assets/templates/puskeswan-admin/');?>img/logo.png" alt="" width="72">
</div>

<div class="ml-0 heading-content-title ml-3 mt-0 p-1 ">
                <h1>PUSKESWAN</h1>

<h5>	

<?php 
	if(@$content_title){
		echo strtoupper(@$content_title);
	}

?>
</h5>
</div>
