        <!-- loader content -->
        <div class="card border-0 mt-2">
            <div class="card-image">
            	<?php $this->load->view('templates/car-sell/animate-loader'); ?>
            </div>
        </div>
        <div class="card-body p-1">
            <div class="card-title" style="height: 20px;">
            	<?php $this->load->view('templates/car-sell/animate-loader'); ?>
            </div>
            <div class="card-title" style="height: 20px;width: 70%;">
            	<?php $this->load->view('templates/car-sell/animate-loader'); ?>
            </div>
            <div class="card-title" style="height: 20px;width: 60%;">
                <?php $this->load->view('templates/car-sell/animate-loader'); ?>
            </div>
            <div class="card-title" style="height: 20px;width: 70%;">
                <?php $this->load->view('templates/car-sell/animate-loader'); ?>
            </div>
        </div>
        <!-- end loader content -->