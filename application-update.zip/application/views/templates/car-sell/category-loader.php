<!-- loader content -->
<div class=" ml-3 w-100">
<div class="card border w-25 mr-2 float-left" style="height: 2.5rem;">
    <?php $this->load->view('templates/car-sell/animate-loader'); ?>
</div>

<div class="card border w-25 mr-2 float-left" style="height: 2.5rem;">
    <?php $this->load->view('templates/car-sell/animate-loader'); ?>
</div>
</div>