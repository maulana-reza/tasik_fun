<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

// bid
$config['bid_title']	 = "Penawaran";
$config['bid']			 = "%s membuat penawaran dengan mobil anda";
// Sold
$config['sold_title']	 = "Terjual";
$config['sold']  		 = "%s telah menjual mobil kepada anda, silahkan cek invoice di email mu";

// confirm (administrator)
$config['upgrade_title'] = "Upgrade";
$config['upgrade']  = "%s mengupgrade akun, silahkan tinjau dokumen yang ada";
// confirm (administrator)
$config['ads_title'] = "Pengiklanan";
$config['ads']   = "%s mengajukan pengiklanan";

