<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


// PROFILE 

 $lang['profile_not_complete']	= 'Please complete your information';
 $lang['upload_success']		= 'Image has been upload';
 $lang['profile_success']		= 'Your profile has been update';
 $lang['user_update']			= 'Document Successfully added, wait until administrator approved';
 $lang['content_success']		= 'Successfully added';
 $lang['content_update']		= 'Successfully update';
 $lang['content_delete']		= 'Successfully delete';
 $lang['document_success']		= 'Document has been added, wait until administrator approval';
 $lang['takedown_success']		= 'Successfully takedown';
 $lang['publish_success']		= 'Successfully Publish';
 $lang['register_success']		= 'Successfully Register';
 $lang['confirm_failed']		= 'Confirm Code not valid';
 $lang['upgrade_success']		= 'Has been upgraded';
 $lang['payment_success']		= 'Has been confirm';
 $lang['choose_payment_success']= 'Successfully';
 $lang['choose_payment_not_valid']= 'Option not valid';
 $lang['content_undefined']		= 'Content Undefined';
 $lang['content_not_found']		= 'Content Not Found';
 $lang['report_success']		= 'Thank for report us.';
 $lang['report_not_found']		= 'Report Not Found';
 $lang['bid_success']			= 'Successfully bid';
 $lang['sold_success']			= 'Successfully Sold';
 $lang['logout_success']		= 'User has been logout';
 $lang['delete_message']		= 'Are you sure?';
 $lang['add']				= 'Successfully';
 $lang['update']		= 'Successfully update';
 $lang['delete']		= 'Successfully delete';
 $lang['not_found']		= 'Not found';
 $lang['empty']		= 'Empty';
 $lang["address_not_valid"]		= 'form address not valid';
 $lang["max_size_upload"]		= 'Max size : 2 MB <br> with format : PNG,JPEG,JPG';
 $lang["location_alert"]		= "Activate your location";
 $lang["bid_success"]			= "Successfully bid, wait until owner contact you."; 
 $lang['location_active']		= "location has active";
