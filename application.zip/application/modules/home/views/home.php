
    <section class="home-slider owl-carousel">
      
   <?= @$banner ;?>
    </section>
    <?= @$documentation;?>
    
    <?= @$category;?>
    <!-- END slider -->
    
<!--     
<div class="col-8 col-md-6 m-auto h-100 text-center" >
 <img src="<?= base_url();?>assets/templates/default/images/in_progress.svg" alt="" class="w-100">
 <div >SEDANG DALAM PROSES</div>
</div>
<style>
@media (max-width:320px) {
    body{font-size: 10px;}
}

@media (max-width:768px) {
    body{font-size: 1em;}
}

@media (min-width:768px) {
	body{
	    font-size: 2.4em;
	}
} 
</style> -->