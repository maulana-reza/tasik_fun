
    
    <div class="section container">
        <div class="row">
            <h2 class="text-center"><?= getenv('APP_NAME');?></h2>

          <div class="col-md-12 p-2 ">
            <?=
            $this->session->userdata('description'); 
            ?>
            </div>

        </div>
      </div>

    </section>
