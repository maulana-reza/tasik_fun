<div class="m-3">
<?php echo $_SESSION['service']; ?>
</div>